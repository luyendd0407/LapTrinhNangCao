#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	int a[100][100];
	int n,m;
	//Cau 1
	
	ifstream infi("data.txt");
	infi >> n;
	infi >> m;
	for (int i =0; i <n;i++){
		for (int j = 0; j <m;j++) a[i][j] = 0;
		int tam;
		while (1){
			infi >> tam;
			if (tam == -1) break;
			a[i][tam-1] = 1;
		}
			
	}
	infi.close();
	//In ket qua
	for (int i =0; i <n;i++){
		for (int j =0; j <m;j++)
			cout << a[i][j] << " ";
		cout << endl;
	}
	int h[100];
	for (int i =0; i <n;i++){
		h[i] = 0;
		for (int j =0; j <m;j++)
		    if (a[i][j] == 1) h[i] = h[i] + 1;
		cout << "H[" << i << "]=" << h[i] << endl;   
	}
	cout << endl;
	//Cau 2
	int giomax = 0;
	for (int i = 0; i <n;i++)
	   if (h[i] > giomax) giomax = h[i];
	cout << "gio co so hang max: " << giomax << endl;
	for (int i =0; i <n;i++)
		if (h[i] == giomax) cout << i << " ";
	cout << endl;
	//Cau 3
	int k;
	cout << "k = "; cin >> k;
	for (int i = k; i <n;i++)
	   for (int j =0; j <m;j++)
	       a[k+1][j] = a[k][j];
	//chen vao
	for (int j = 0;j <m;j++) a[k][j] = 0;
	cout << "Nhap thong tin cua gio hang:";
	while (1){
		int tam;
		cin >> tam;
		if (tam == -1) break;
		a[k][tam-1] = 1;
	}  

	for (int i =0; i <n+1;i++){
		for (int j =0; j <m;j++)
			cout << a[i][j] << " ";
		cout << endl;
	}	
	
	return 0;
}

