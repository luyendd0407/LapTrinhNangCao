#include <iostream>
#include <fstream>

using namespace std;

int Lj(int a[100][100], int n, int j)
{
	int c[100];
	for (int i =0; i <100;i++)
		c[i] = 0;
	for (int i =0; i <n;i++)
	    c[a[i][j]] = c[a[i][j]] + 1;
	int somau = 0;    
	for (int i = 0; i <100;i++)		
	   if (c[i] > 0) somau = somau + 1;
	return somau;
}

int Lmax(int a[100][100], int n)
{
	int maumax = Lj(a,n,0);
	for (int j =1; j <n;j++)
	   if (maumax < Lj(a,n,j))
	   	    maumax = Lj(a,n,j);
	return maumax;
}


int main()
{
	
	int n;
	int a[100][100];
	ifstream infi("color.dat");
	infi >> n;
	for (int i =0; i <n;i++)
	    for (int j =0; j <n;j++)
	        infi >> a[i][j];
	infi.close();
		
	//Cau 1
	cout << Lj(a, n, 0) << endl; 
	//Cau 2
	cout << "Do da sac la:" << Lmax(a,n);
	return 0;
}
