#include <iostream>

using namespace std;

void DoiCho(int &a, int &b)
{
	int tam = a;
	a = b;
	b = tam;
}

int main()
{
	int x = 10;
	int y = 20;
	cout << x << " va " << y << endl;
	DoiCho(x,y);
	cout << x << " va " << y << endl; 
	return 0;
}
