#include <iostream>
#include <fstream>

using namespace std;

int KtNguyenTo(int n)
{
	if (n <2) return 0;
	for (int i = 2; i < n/2 +1; i++)
		if (n % i == 0) return 0;
	return 1;
}

int FindSub(int a[100][100], int n, int m, int c[3][3])
{
	for (int i =0; i <n-2;i++)
		for (int j =0;j <m-2;j++){
			int tong = 0;
			for (int p =0; p<3;p++)
				for (int q =0; q<3;q++)
				    tong = tong + a[i+p][j+q];
			if (tong >0 && KtNguyenTo(tong)){
				
				for (int p =0; p <3;p++)
				   for (int q = 0; q <3;q++)
				       c[p][q] = a[i+p][j+q];
				return 1;			
			}
			
				  
		}	 
	return 0; 	
}

int main()
{
	//doc du lieu
	int m,n;
	int a[100][100];
	
	ifstream infile("matrix.txt");
	infile >> n;
	infile >> m;
	for (int i =0; i <n;i++)
		for (int j =0; j <m;j++)
			infile >> a[i][j];
	infile.close();
	//Cau 2.2
	//int kt = 0;
	/*for (int i =0; i <n-2;i++)
		for (int j =0;j <m-2;j++){
			int tong = 0;
			for (int p =0; p<3;p++)
				for (int q =0; q<3;q++)
				    tong = tong + a[i+p][j+q];
			if (tong >0 && KtNguyenTo(tong)){
				cout << 1 << endl;
				for (int p = 0; p <3;p++){
					for (int q =0; q<3;q++)
						cout << a[i+p][j+q] << " ";
					cout << endl;
			    }
				return 0;			
			}
			
				  
		}  
	*/
	int c[3][3];
	if (FindSub(a,n,m,c)){
		cout << 1 << endl;
		for (int p = 0; p <3;p++){
			for (int q =0; q<3;q++)
				cout << c[p][q] << " ";
			cout << endl;
		}		
	}
	else cout << 0 << endl;
	return 0;
}

