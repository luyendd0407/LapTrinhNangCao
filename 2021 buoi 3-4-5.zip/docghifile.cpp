#include <iostream>
#include <fstream>

using namespace std;
int main()
{
	/*ofstream outfi("dayso.txt");
	outfi << 15 << endl;
	for (int i =0; i <15;i++)
		outfi << i*i << " ";
		
	outfi.close();*/
	ifstream infi("dayso.txt");
	int n;
	int a[100];
	infi >> n;
	for (int i =0; i <n;i++)
		infi >> a[i];
	
	//Kiem tra du lieu
	cout << n << endl;
	for (int i =0; i <n;i++)
		cout << a[i] << " ";	
	
	return 0;
}

