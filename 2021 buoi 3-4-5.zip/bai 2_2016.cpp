#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	//doc du lieu
	int m,n;
	int a[100][100];
	
	ifstream infile("matrix.txt");
	infile >> n;
	infile >> m;
	for (int i =0; i <n;i++)
		for (int j =0; j <m;j++)
			infile >> a[i][j];
	infile.close();
	// Cau 1
	int tt[100];
	for (int j =0; j <m;j++){
		tt[j] = 0;
		for (int i =0; i <n;i++)
			if (a[i][j] == 1) tt[j] = tt[j] + 1;
		cout << j << "(" << tt[j] << "); ";
	}
	cout << endl;
	//Cau 2
	int tt_chung[100][100];
	for (int j =0; j <m-1;j++)
		for (int k= j+1; k<m;k++){
			tt_chung[j][k] = 0;
			for (int i =0; i<n;i++)
			    if (a[i][j] == 1 && a[i][k] == 1)
				    tt_chung[j][k] = tt_chung[j][k] + 1; 
			cout << j << "-" << k << "(" << tt_chung[j][k] << "); ";
		}
	
	cout << endl;
	//Cau 3
	for (int j =0; j <m-1;j++)
		for (int k= j+1; k<m;k++){
			float jc = (float)tt_chung[j][k]/(tt[j]+tt[k]- tt_chung[j][k]);
			cout << j << "-" << k << "(" << jc << "); ";
		}
			
	return 0;
}
