#include <iostream>

using namespace std;

int main()
{
	int n;
	int a[100];
	//Nhap du lieu
	cout << "n="; cin >> n;
	for (int i =0; i <n;i++){
		cout << "a[" << i << "]=";
		cin >> a[i];
	}
	//Cau 1
	//Duyet tung day so gom 4 so trong day ban dau
	//if day nao thoa man chia 2 va cho 5 thi in ra ket qua
	int tongmax = -1000;
	int b[4];
	for (int i =0; i <n-3;i++){
		int tong = 0;
		for (int j = 0; j<4;j++)
		   tong = tong + a[i+j];
		if (tong %2 == 0 && tong %5 == 0){
			if (tong >tongmax) {
				tongmax = tong;
				for (int j = 0; j <4;j++) b[j] = a[i+j];
			}
			for (int j = 0; j <4;j++)
			    cout << a[i+j] << " ";
		    cout << endl;
		}
		       
	}
	//Cau 2
	cout << "Day co tong max la: ";
	for (int i =0; i <4;i++)   
	    cout << b[i] << " ";
	cout << endl;
	return 0;
}
