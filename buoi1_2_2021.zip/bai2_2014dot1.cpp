#include <iostream>

using namespace std;

int USCLN(int a, int b)
{
	//(a,b) = (b, a%b) = ... = (k,0) = k
	while (b!=0){
		int k = a%b;
		a = b;
	    b = k;	
	}
	return a;
}

int main()
{
	int n;
	int a[100];
	cout << "n="; cin >> n;
	for (int i =0; i <n;i++){
		cout << "a[" << i << "]=";
		cin >> a[i];
	}
	//Cau 2.2
	//Thuat toan: 
	//USCLN(a,b) 
	//Duyet cac cap so x,y ma USCLN(x,y) = 1
	//Tim cap (x,y) ma co tong lon nhat
	//In ra neu tim thay nguoc lai thi in ra so 0
	int tmax = 0;
	int x,y;
	for (int i =0; i <n-1;i++)
	   for (int j = i+1; j <n;j++)
	       if ((a[i] > 0) && (a[j]> 0) && USCLN(a[i],a[j]) == 1){
	       	    if (a[i] + a[j] > tmax) {
				   tmax = a[i] + a[j];	 
				   x = a[i];
				   y = a[j];
				}
				      	          	    
		   }
	       
	//In ket qua
	if (tmax >0) cout << x << " " << y << endl;
	else
	   cout << 0;
		
	return 0;
}
