#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	int n;
	int h[100];
	cout << "n="; cin >> n;
	for (int i =0; i <n;i++){
		cout << "h[" << i << "]=";
		cin >> h[i];
	}
	//Cau 2.1
	int tong = 0;
	for (int i =0; i <n;i++)
	    tong = tong + h[i];
	float tb = (float)tong/n;   
	cout << "Cau 1:" << tb << endl; 
	//Cau 2.2
	cout << "cau 2: ";
	for (int i =0; i<n;i++)
	   if (h[i] >tb) cout << i+1 << " ";
	cout << endl;
	//Cau 2.3
	float s =0;
	for (int i=0; i <n;i++)
	    s = s + (h[i]-tb)*((h[i]-tb));
	s = sqrt(s/(n-1));
	cout << "Cau 3: " << s << endl;
		
	return 0;	
}
