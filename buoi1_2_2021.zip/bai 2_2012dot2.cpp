#include <iostream>
using namespace std;
int main()
{
	
	int n;
	int a[100];
	cout << "n="; cin >> n;
	
	for (int i =0; i <n;i++){
		cout << "a[" << i << "]=";
		cin >> a[i];
	}
	for (int i =0; i <n;i++){
		int tong = 0;
		for (int j=i;j<n;j++){
			tong = tong + a[j];
			if (tong == 0) cout << i << "," << j << endl;
		}		
	}
	
	return 0;
}
